
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.swing.JOptionPane;


public class Database {
	
	private Properties connectionProps;
	private Connection con;
	private Statement st;
	private DatabaseMetaData meta;
	
	public Database(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			this.connectionProps = new Properties();
			this.connectionProps.put("user", "a01630895");
			this.connectionProps.put("password", "tec0895");
			this.con = DriverManager.getConnection("jdbc:oracle:thin:@info.gda.itesm.mx:1521/alumXDB.gda.itesm.mx",connectionProps);
			this.st = con.createStatement();
			this.meta = con.getMetaData();
		}
		catch (Exception e){
			System.out.println(e);
		}
	}
	
	//select
	private String[][] getQuery(String query, int size){
		String[] temp;
		List<String[]> rslt = new ArrayList<String[]>();
		ResultSet rs;
		try {
			rs = this.st.executeQuery(query);
			while(rs.next()){
				temp = new String[size];
				for (int i = 0; i < size; i++) {
					Object obj = rs.getObject(i+1);
					if(obj == null)
						obj = "";
					temp[i] = obj.toString();
					
				}
				rslt.add(temp);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		String[][] result = new String[rslt.size()][size];
		rslt.toArray(result);
		return result;	
	}
	
	private String[] getQuery(String sql){
		List<String> rslt = new ArrayList<String>();
		ResultSet rs;
		try {
			rs = this.st.executeQuery(sql);
			while(rs.next())
				rslt.add(rs.getString(1));
			
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
		String[] result = new String[rslt.size()];
		rslt.toArray(result);
		return result;
	}
	
	//Insert o update directamente
	private void updateValues(String sql){
		try {
			this.st.executeUpdate(sql);
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		} 
	}
	
	//Llamar funci�n sql
	private void callFunction(CallableStatement cs){
		try {
			cs.executeUpdate();
			String msg = cs.getString(1);
			JOptionPane.showMessageDialog(null, msg);
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Excepcion " + e.getClass().getName());
		}
	}
	
	//Queries
	
	public int getNumAlmacen(String nombre){
		String sql = "select nalmacen from almacen where nombre='" + nombre +"'";
		int rslt = 0;
		ResultSet rs;
		try {
			rs = this.st.executeQuery(sql);
			while(rs.next())
				rslt = rs.getInt(1);
			
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
		return rslt;
	}
	
	public String[][] getViewGerenteMov(){
		String sql = "select * from gerente_movimientos";
		return getQuery(sql,5);
	}
	
	public String[][] getViewGerenteMov(String sql){
		return getQuery(sql,5);
	}
	
	public String[][] getViewGerenteAlmacenista(){
		String sql = "select * from gerente_almacenistas";
		return getQuery(sql, 4);
	}
	
	public String[][] getViewGerenteAlmacenInsumos(Object nAlmacen){
		String sql = "select nombre, cantnecesaria, cantactual, estado from gerente_almacenes where nalmacen=" + nAlmacen;
		return getQuery(sql,4);
	}
	
	public String[][] getViewGerenteInsumos(){
		String sql = "select * from gerente_insumos";
		return getQuery(sql,5);
	}
	
	public String[][] getViewGerenteProveedores(){
		String sql = "select * from gerente_proveedores";
		return getQuery(sql,3);
	}
	
	public String[] getViewGerenteAlmacenInfo(Object nAlmacen){
		String sql = "select * from almacen where nalmacen=" + nAlmacen;
		return getQuery(sql,4)[0];
	}
	
	public String[] getViewGerenteAlmacenItems(){
		String sql = "select nombre from almacen";
		return getQuery(sql);
	}
	
	public String[] getViewGerenteFechas(){
		String sql = "select distinct trunc(fecha) from movimientos";
		String[] fechas = getQuery(sql);
		for(int i = 0; i < fechas.length; i++){
			fechas[i] = fechas[i].split("\\s+")[0];
		}
		return fechas;
	}
	
	public String[] getViewGerenteInsumoItems(){
		String sql = "select nombre from proveedor";
		return getQuery(sql);
	}

	public String[] getGerenteInfo(String clave){
		String sql = "select clave, nombre from gerente where clave = " + clave;
		List<String> rslt = new ArrayList<String>();
		ResultSet rs;
		try {
			rs = this.st.executeQuery(sql);
			while(rs.next()){
				rslt.add(rs.getObject(1).toString());
				rslt.add(rs.getObject(2).toString());
			}
			
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
		String[] result = new String[rslt.size()];
		rslt.toArray(result);
		return result;
	}
	
	public String[] getAlmacenistaInfo(String clave){
		String sql = "select clave, nombre from almacenista where clave = " + clave;
		List<String> rslt = new ArrayList<String>();
		ResultSet rs;
		try {
			rs = this.st.executeQuery(sql);
			while(rs.next()){
				rslt.add(rs.getObject(1).toString());
				rslt.add(rs.getObject(2).toString());
			}
			
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
		String[] result = new String[rslt.size()];
		rslt.toArray(result);
		return result;
	}
	
	public String[] getViewGerenteInsumoItems(int almacen){
		String sql = "select p.nombre from producto p where not exists(select * from insumo where p.clave = insumo.clave and nalmacen =" + almacen + ")";
		return getQuery(sql);
	}
	
	public String[] getClavesGerente(){
		String sql = "select clave from gerente";
		List<String> rslt = new ArrayList<String>();
		ResultSet rs;
		try {
			rs = this.st.executeQuery(sql);
			while(rs.next()){
				rslt.add(rs.getObject(1).toString());
			}
			
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
		String[] result = new String[rslt.size()];
		rslt.toArray(result);
		return result;
	}
	
	public String[] getClavesAlmacenista(){
		String sql = "select clave from almacenista";
		List<String> rslt = new ArrayList<String>();
		ResultSet rs;
		try {
			rs = this.st.executeQuery(sql);
			while(rs.next()){
				rslt.add(rs.getObject(1).toString());
			}
			
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
		String[] result = new String[rslt.size()];
		rslt.toArray(result);
		return result;
	}
	
	//Inserts
	public void insertarAlmacen(int numero, String nombre, String empresa, String direccion){
		CallableStatement cs;
		try {
			cs = con.prepareCall("begin ? := insertar_almacen(?,?,?,?); end;");
			cs.registerOutParameter(1, Types.VARCHAR);
			cs.registerOutParameter(2, Types.INTEGER);
			cs.registerOutParameter(3, Types.VARCHAR);
			cs.registerOutParameter(4, Types.VARCHAR);
			cs.registerOutParameter(5, Types.VARCHAR);
			
			cs.setString(1, "");
			cs.setInt(2, numero);
			cs.setString(3, nombre);
			cs.setString(4, empresa);
			cs.setString(5, direccion);
			this.callFunction(cs);
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
	}
	
	public void insertarAlmacenista(int clave, String nombre, String telefono, String direccion, int claveGerente){
		CallableStatement cs;
		try {
			cs = con.prepareCall("begin ? := insertar_almacenista(?,?,?,?,?); end;");
			cs.registerOutParameter(1, Types.VARCHAR);
			cs.registerOutParameter(2, Types.INTEGER);
			cs.registerOutParameter(3, Types.VARCHAR);
			cs.registerOutParameter(4, Types.VARCHAR);
			cs.registerOutParameter(5, Types.VARCHAR);
			cs.registerOutParameter(6, Types.INTEGER);
			
			cs.setString(1, "");
			cs.setInt(2, clave);
			cs.setString(3, nombre);
			cs.setString(4, telefono);
			cs.setString(5, direccion);
			cs.setInt(6, claveGerente);
			this.callFunction(cs);
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
	}
	
	public void insertarProducto(int clave, String nombre, String tipo, String unidad, String contenido, String proveedor, int claveGerente){
		CallableStatement cs;
		try {
			cs = con.prepareCall("begin ? := insert_producto(?,?,?,?,?,?,?); end;");
			cs.registerOutParameter(1, Types.VARCHAR);
			cs.registerOutParameter(2, Types.INTEGER);
			cs.registerOutParameter(3, Types.VARCHAR);
			cs.registerOutParameter(4, Types.VARCHAR);
			cs.registerOutParameter(5, Types.VARCHAR);
			cs.registerOutParameter(6, Types.VARCHAR);
			cs.registerOutParameter(7, Types.VARCHAR);
			cs.registerOutParameter(8, Types.INTEGER);
			
			cs.setString(1, "");
			cs.setInt(2, clave);
			cs.setString(3, nombre);
			cs.setString(4, tipo);
			cs.setString(5, unidad);
			cs.setString(6, contenido);
			cs.setString(7, proveedor);
			cs.setInt(8, claveGerente);
			this.callFunction(cs);
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
	}
	
	public void insertarProveedor(int clave, String nombre, String telefono, String email){
		CallableStatement cs;
		try {
			cs = con.prepareCall("begin ? := insert_proveedor(?,?,?,?); end;");
			cs.registerOutParameter(1, Types.VARCHAR);
			cs.registerOutParameter(2, Types.INTEGER);
			cs.registerOutParameter(3, Types.VARCHAR);
			cs.registerOutParameter(4, Types.VARCHAR);
			cs.registerOutParameter(5, Types.VARCHAR);
			
			cs.setString(1, "");
			cs.setInt(2, clave);
			cs.setString(3, nombre);
			cs.setString(4, telefono);
			cs.setString(5, email);
			this.callFunction(cs);
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Excepcion " + e.getClass().getName());
		}
	}
	
	public void insertarInsumo(int almacen, String producto, int cantnec, int cantactual){
		CallableStatement cs;
		try {
			cs = con.prepareCall("begin ? := insert_insumo(?,?,?,?); end;");
			cs.registerOutParameter(1, Types.VARCHAR);
			cs.registerOutParameter(2, Types.INTEGER);
			cs.registerOutParameter(3, Types.VARCHAR);
			cs.registerOutParameter(4, Types.INTEGER);
			cs.registerOutParameter(5, Types.INTEGER);
			
			cs.setString(1, "");
			cs.setInt(2, almacen);
			cs.setString(3, producto);
			cs.setInt(4, cantnec);
			cs.setInt(5, cantactual);
			this.callFunction(cs);
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
	}
	
	//Updates
	public void update_producto_nombre(String actual, String nuevo){
		CallableStatement cs;
		try {
			cs = con.prepareCall("begin ? := update_nombre_producto(?,?); end;");
			cs.registerOutParameter(1, Types.VARCHAR);
			cs.registerOutParameter(2, Types.VARCHAR);
			cs.registerOutParameter(3, Types.VARCHAR);
			cs.setString(1, "");
			cs.setString(2, nuevo);
			cs.setString(3, actual);
			this.callFunction(cs);
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
	}
	
	public void update_producto_tipo(String actual, String nuevo){
		CallableStatement cs;
		try {
			cs = con.prepareCall("begin ? := update_tipo_producto(?,?); end;");
			cs.registerOutParameter(1, Types.VARCHAR);
			cs.registerOutParameter(2, Types.VARCHAR);
			cs.registerOutParameter(3, Types.VARCHAR);
			cs.setString(1, "");
			cs.setString(2, nuevo);
			cs.setString(3, actual);
			this.callFunction(cs);
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
	}
	
	public void insert_usario(int clave, int nalmacen){
		String sql = "insert into usuario values(" + clave + "," + nalmacen + ")";
		this.updateValues(sql);
	}
		 
	public void update_usuario(int clave, int nalmacen){
		String sql= "update usuario set almacen=" + nalmacen + "where clave=" +clave;
		this.updateValues(sql);
	}
		 
	public void delete_usuario(int clave){
		String sql = "delete from usuario where clave=" +clave;
		this.updateValues(sql);
	}
	
	public void update_producto_unidad(String actual, String nuevo){
		CallableStatement cs;
		try {
			cs = con.prepareCall("begin ? := update_unidad_producto(?,?); end;");
			cs.registerOutParameter(1, Types.VARCHAR);
			cs.registerOutParameter(2, Types.VARCHAR);
			cs.registerOutParameter(3, Types.VARCHAR);
			cs.setString(1, "");
			cs.setString(2, nuevo);
			cs.setString(3, actual);
			this.callFunction(cs);
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
	}
	
	public void update_producto_contenido(String actual, String nuevo){
		CallableStatement cs;
		try {
			cs = con.prepareCall("begin ? := update_contenido_producto(?,?); end;");
			cs.registerOutParameter(1, Types.VARCHAR);
			cs.registerOutParameter(2, Types.VARCHAR);
			cs.registerOutParameter(3, Types.VARCHAR);
			cs.setString(1, "");
			cs.setString(2, nuevo);
			cs.setString(3, actual);
			this.callFunction(cs);
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
	}
	
	public void update_cantidad(String funcion, int almacen, String nombre, int nuevo){
		CallableStatement cs;
		try{
			cs = con.prepareCall("begin ? := update_cant" + funcion + "(?,?,?); end;");
			cs.registerOutParameter(1, Types.VARCHAR);
			cs.registerOutParameter(2, Types.INTEGER);
			cs.registerOutParameter(3, Types.VARCHAR);
			cs.registerOutParameter(4, Types.INTEGER);
			cs.setString(1, "");
			cs.setInt(2, almacen);
			cs.setString(3,nombre);
			cs.setInt(4, nuevo);
			this.callFunction(cs);
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
	}
	
	public void update_almacenista(String funcion, String nombre, String nuevo){
		CallableStatement cs;
		try{
			cs = con.prepareCall("begin ? := update_almacenista_"+funcion+"(?,?); end;");
			cs.registerOutParameter(1, Types.VARCHAR);
			cs.registerOutParameter(2, Types.VARCHAR);
			cs.registerOutParameter(3, Types.VARCHAR);
			cs.setString(1,"");
			//cs.setInt(2, clave);
			cs.setString(2,nombre);
			cs.setString(3,nuevo);
			this.callFunction(cs);
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
	}
	
	public void update_almacenista_nombre(int clave, String nuevo){
		CallableStatement cs;
		try{
			cs = con.prepareCall("begin ? := update_almacenista_nombre(?,?); end;");
			cs.registerOutParameter(1, Types.VARCHAR);
			cs.registerOutParameter(2, Types.NUMERIC);
			cs.registerOutParameter(3, Types.VARCHAR);
			cs.setString(1,"");
			cs.setInt(2, clave);
			cs.setString(3,nuevo);
			this.callFunction(cs);
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
	}
	
	public void update_proveedor(String funcion, String nombre, String nuevo){
		CallableStatement cs;
		try{
			cs = con.prepareCall("begin ? := update_proveedor_"+funcion+"(?,?); end;");
			cs.registerOutParameter(1, Types.VARCHAR);
			cs.registerOutParameter(2, Types.VARCHAR);
			cs.registerOutParameter(3, Types.VARCHAR);
			cs.setString(1,"");
			cs.setString(2,nombre);
			cs.setString(3,nuevo);
			this.callFunction(cs);
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
	}
	
	public void update_almacen(int nalmacen, String atributo, String nuevo){
		String sql = "update almacen set " + atributo + "='" + nuevo + "' where nalmacen=" + nalmacen;
		this.updateValues(sql);
	}
	
	public void entrada_insumo(int almacen, String nombre, int cambio){
		CallableStatement cs;
		try{
			cs = con.prepareCall("begin ? := entrada_insumo(?,?,?); end;");
			cs.registerOutParameter(1, Types.VARCHAR);
			cs.registerOutParameter(2, Types.INTEGER);
			cs.registerOutParameter(3, Types.VARCHAR);
			cs.registerOutParameter(2, Types.INTEGER);
			cs.setString(1, "");
			cs.setInt(2, almacen);
			cs.setString(3,nombre);
			cs.setInt(4,cambio);
			this.callFunction(cs);
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
	}
	
	//delete
	
	public void delete_almacen(int nalmacen){
		  String sql = "delete from almacen where nalmacen=" + nalmacen;
		  this.updateValues(sql);
	}
	
	public void delete_insumo(int almacen, String nombre){
		CallableStatement cs;
		try{
			cs = con.prepareCall("begin ? := delete_insumo(?,?); end;");
			cs.registerOutParameter(1, Types.VARCHAR);
			cs.registerOutParameter(2, Types.INTEGER);
			cs.registerOutParameter(3, Types.VARCHAR);
			cs.setString(1, "");
			cs.setInt(2, almacen);
			cs.setString(3,nombre);
			this.callFunction(cs);
		} catch (SQLException e) {
			System.out.println("Excepcion " + e.getClass().getName());
		}
	}
	
	public void delete_almacenista(String nombre){
		String sql = "delete from almacenista where nombre=" + nombre;
		this.updateValues(sql);
	}
	
	public void delete_producto(String nombre){
		String sql = "delete from producto where nombre=" + nombre;
		this.updateValues(sql);
	}
	
	public void delete_proveedor(String nombre){
		String sql = "delete from proveedor where nombre=" + nombre;
		this.updateValues(sql);
	}
	
	
	public static void main(String[] args){
		Database db = new Database();
		String[][] t = db.getViewGerenteProveedores();
		for (int i = 0; i < t.length; i++) {
			for (int j = 0; j < t[i].length; j++) {
				System.out.println(t[i][j]);
			}
			
		}
	}
}
