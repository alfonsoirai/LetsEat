
import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class Table extends JPanel{

	private static final long serialVersionUID = 1L;
	private String[] columnNames;
	private String[][] data;
	protected JTable table;
	private JScrollPane scrollPane;
	protected int row, column;
	protected String oldValue, newValue;
	private int num;

	public Table(String[] names, String[][] data, int n) {
		setBackground(new Color(255, 255, 255));
		this.setPreferredSize(new Dimension(735,450));
		this.num = n;
		this.columnNames = names;
		this.data = data;
		DefaultTableModel model = new DefaultTableModel(this.data, this.columnNames){
		    /**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public boolean isCellEditable(int r, int c) {
				switch(num){
				case 1:
					if(c==3 || c == 0)
						return false;
					else
						return true;
				case 2:
					if(c == 3)
						return false;
					else
						return true;
				case 3:
					if(c == 4)
						return false;
					else 
						return true;
				case 5:
					return false;
				case 6:
					if(c == 0 || c == 1 || c == 3)
						return false;
					else
						return true;
				}
				return true;
		    }

		   };
		this.table = new JTable(model);
		this.table.setBounds(0,0,730,360);
		if(this.num == 1)
			this.table.setPreferredScrollableViewportSize(new Dimension(700,300));
		else if (this.num == 6)
			this.table.setPreferredScrollableViewportSize(new Dimension(720,374));
		else
			this.table.setPreferredScrollableViewportSize(new Dimension(700,374));
		this.table.setFillsViewportHeight(true);
		this.scrollPane = new JScrollPane(this.table);
		this.scrollPane.setBounds(0, 0, 730, 375);
		scrollPane.setBackground(new Color(255, 255, 255));
		this.add(this.scrollPane);
		this.table.setFont(new Font("Arial", Font.PLAIN, 14));
		this.table.getTableHeader().setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 14));
		this.table.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 14));
		this.table.setRowHeight(table.getRowHeight()+30);
	}
	
	public void removeRow(int rowNum){
		((DefaultTableModel) table.getModel()).removeRow(rowNum);
	}


}
